from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('web_dev', views.web_dev, name='web_dev'),
    path('phone_app', views.phone_app, name='phone_app'),
]